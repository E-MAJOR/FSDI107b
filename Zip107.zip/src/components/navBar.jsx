//java script react project
//<button>This is a Test</button> removed from div from under h5
//create component to show product, with img, title h2, price label, total label, and 'add' button within a container with div tag

import"./navBar.css";
const NavBar = () => {
    return (
        <div className="navbar">
            <h5>Nav menu will be here</h5>
        </div>
    );
}
//use somewhere else
export default NavBar;