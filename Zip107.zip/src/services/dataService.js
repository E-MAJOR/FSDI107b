var catalog = [
    {
        _id:"vege101",
        title:"Carrots",
        price:4.99,
        stock:12, 
        image:"carrot.jpg",
        category:"Vegetable"
    },
    {
        _id:"frui101",
        title:"Strawberries",
        price:3.99,
        stock:9, 
        image:"strawberry.jpg",
        category:"Fruit"
    }, 
    {
        _id:"vege102",
        title:"Tomatoes",
        price:2.99,
        stock:10, 
        image:"tomato.jpg",
        category:"Vegetable"
    },
    {
        _id:"frui102",
        title:"Apples",
        price:5.99,
        stock:11, 
        image:"apple.jpg",
        category:"Fruit"
    },
    {
        _id:"dair101",
        title:"Milk (Pint)",
        price:2.50,
        stock:8, 
        image:"milk.jpg",
        category:"Dairy"
    },   
    
];




class DataServices {

    //method 
    getCatalog() {
        //do to connect to server
        //retrieve data

        return catalog;
    }

}

export default DataServices;